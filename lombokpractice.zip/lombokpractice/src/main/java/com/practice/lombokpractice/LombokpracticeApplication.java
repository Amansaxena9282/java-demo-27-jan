package com.practice.lombokpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LombokpracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LombokpracticeApplication.class, args);
	}

}
